<script setup>
import useTodos from "../composables/useTodos";

const {pending, completed, changeStatus} = useTodos();

defineProps({
    isCompleted: {
        default: false,
        type: Boolean,
    },
});
</script>


<template>
        <div class="w-1/3">
          <h3 class="text-2xl text-center" :class="isCompleted ? 'text-green-800' : 'text-blue-700'">{{isCompleted ? "Completed" : "Pending"}}</h3>
          <ul class="pt-8 space-y-4">
            <li
              v-for="todo in isCompleted ? completed : pending"
              :key="todo.id"
              @click="changeStatus(todo.id)"
              :class="isCompleted ? 'text-green-500 hover:bg-green-300' : 'text-blue-500 hover:bg-blue-300'"
              class="w-full px-4 py-2 font-bold text-center  duration-500 bg-purple-200 rounded-lg  hover:cursor-pointer  hover:text-purple-500"
            >
              {{ todo.content }}
            </li>
          </ul>
        </div>
</template>